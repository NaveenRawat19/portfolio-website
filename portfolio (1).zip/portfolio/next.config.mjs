// BASE_PATH is set by the deploy workflow: "/<repo>" for project sites,
// empty for a <user>.github.io repo or local development.
const basePath = process.env.BASE_PATH || "";

/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "export",
  basePath,
  trailingSlash: true,
  images: { unoptimized: true },
};

export default nextConfig;
