# Portfolio

Next.js 14 (App Router, TypeScript), plain CSS, no other dependencies.

## Run

    npm install
    npm run dev      # http://localhost:3000

## Fill it in

All copy is in `lib/content.ts`. Anything starting with `TODO` shows up
highlighted in yellow on the page, so you can see what's left.
Remove the highlight automatically by replacing the text.

Add a project: add an object to `projects`; the page at `/projects/<slug>`
is generated for you.

## Deploy

Push to GitHub and import the repo on Vercel (free tier is enough).

## Interactive parts

- `components/AgentRun.tsx`: the hero's clickable agent run. Steps and example text live in `agentSteps` in `lib/content.ts`. It is a generic illustration; edit the text to match how your own systems work.
- `components/ArchDiagram.tsx`: the architecture diagram on each project page. Edit each project's `architecture` (nodes, notes, edges) in `lib/content.ts`. Nodes with `placeholder: true` draw dashed.

## Deploy to GitHub Pages

The workflow in `.github/workflows/deploy.yml` builds a static export and
publishes it on every push to `main`.

1. Create a GitHub repo and push this project to the `main` branch.
2. In the repo, open Settings, then Pages, and set Source to "GitHub Actions".
3. Push to `main` (or run the workflow manually from the Actions tab).
4. The site appears at `https://<user>.github.io/<repo>/`.

If the repo is named `<user>.github.io`, the site is served from the root and
the base path is left empty automatically. A custom domain also needs an empty
base path: remove the "Set base path" step.

Local check of the production build: `npm run build`, then serve the `out/`
folder.
